package webservice;

/**
 * Created by IDEA
 * User:    tiztm
 * Date:    2016/7/12.
 */
public interface  TestWebService {

    public String echo();
}
