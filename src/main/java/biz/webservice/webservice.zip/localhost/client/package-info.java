@javax.xml.bind.annotation.XmlSchema(namespace = "http://localhost/client")
package webservice.localhost.client;
